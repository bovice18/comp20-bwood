Beau Wood
ScoreCenter

1. I have correctly implemented the following:
-Created a Heroku application
-Created a database using Mongo
-Created 4 different JSON based APIs
	-"/" - index, displays all scores in the database
	-"/highscores.json" - using a query, will display all the scores for a specific game
	-"/usersearch" - allows the user to type in a username and then be shown all the scores for that username
	-"/submit.json" - Allows any HTML5 game on any domain to send scores to my application.
-Enabled CORS

2. I have collaborated with Ben Leiken and Sean Harrington to complete this assignment

3. 10 hours approximately

